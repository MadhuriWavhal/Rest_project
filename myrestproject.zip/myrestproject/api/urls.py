from django.urls import path, include
from .views import article_list, article_detail, ArticleAPIView,ArticleDetails,GenericAPIView,ArticleViewSet,ArticlesViewSet,get_articles_raw
from rest_framework.routers import DefaultRouter




router = DefaultRouter()
router.register('article', ArticlesViewSet, basename='article')

urlpatterns = [
    
    path('article/', article_list),#function based
   # path('article/', ArticleAPIView.as_view(),name='av'),
    path('detail/<int:pk>/', article_detail),#function based
    path('detail/<int:id>/', ArticleDetails.as_view(),name='ad'),
    path('generic/article/<int:id>/', GenericAPIView.as_view()),
    path('viewset/', include(router.urls)),
    path('viewset/<int:pk>/', include(router.urls)),

    path('articles/raw/', get_articles_raw, name='get_articles_raw'),#raw queryset




]



